def forecast():
    'fake daily forecast'
    return 'like yesterday'
