# -*- coding: utf-8 -*-

print u"У Мэри был маленьктй барашек."
print u"Его шерсть была белой как %s." % u'снег'
print u"И всюду, куда Мэри шла,"
print u"Маленький барашек всегда следовал за ней."
# Вывод 10 точек в виде строки
print u"." * 10

end1 = u"Б"
end2 = u"а"
end3 = u"д"
end4 = u"д"
end5 = u"и"
end6 = u"Г"
end7 = u"а"
end8 = u"й"

print end1 + end2 + end3 + end4 + end5,
print end6 + end7 + end8
