# -*- coding: utf-8 -*-

print u"Смотрите: ex24.py и ex25.py они правильные!"
