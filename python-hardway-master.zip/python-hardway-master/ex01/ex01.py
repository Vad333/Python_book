# -*- coding: utf-8 -*-

print u'Привет, Мир!'
print u'Это мой первый код на "Python",'
print u'Я бы сказал, что это круто!'
