# -*- coding: utf-8 -*-

animals = [u'медведь', u'тигр', u'пингвин', u'зебра']
bear = animals[0]
