"""
Module containing Python code for Chapter 5.
"""
