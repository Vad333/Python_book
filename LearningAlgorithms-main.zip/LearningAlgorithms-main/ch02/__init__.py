"""
Module containing Python code for Chapter 2.
"""
