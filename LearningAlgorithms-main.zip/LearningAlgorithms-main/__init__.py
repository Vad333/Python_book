"""
Module containing Python code for Learning Algorithms
"""
