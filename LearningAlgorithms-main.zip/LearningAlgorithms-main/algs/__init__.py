"""
Module containing Python code to support the book.
"""
