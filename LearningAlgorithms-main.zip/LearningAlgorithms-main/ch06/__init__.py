"""
Module containing Python code for Chapter 6.
"""
