Images will be generated into this directory.
