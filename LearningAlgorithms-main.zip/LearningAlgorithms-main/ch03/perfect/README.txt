Note that hashFile.py contained the full output from perfect-hash, 
which includes a self-check at the end with the actual words used to
generate the perfect hash. 

generated_dictionary only contains the actual G, S1, S2, hash_f and 
perfect_hash functions

