"""
Module containing Python code for Perfect Hashing as part of Chapter 3.
"""
